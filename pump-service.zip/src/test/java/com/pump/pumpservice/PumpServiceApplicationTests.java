package com.pump.pumpservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PumpServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
