package com.pump.pumpservice.requestmappers;

import java.util.Date;

public class DateMapper {
    private Date date;

    public DateMapper() {
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
