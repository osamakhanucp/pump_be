package com.pump.pumpservice.nozzles;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NozzleRepository extends JpaRepository<Nozzle,Long> {
}
