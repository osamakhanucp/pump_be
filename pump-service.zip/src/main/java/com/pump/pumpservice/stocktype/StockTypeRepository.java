package com.pump.pumpservice.stocktype;


import org.springframework.data.jpa.repository.JpaRepository;

public interface StockTypeRepository extends JpaRepository<StockType, Long> {
}
